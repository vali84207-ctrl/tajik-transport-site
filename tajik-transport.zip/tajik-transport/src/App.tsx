import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { setAuthTokenGetter } from "@workspace/api-client-react";
import { setUploadAuthTokenGetter } from "@workspace/object-storage-web";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { getAdminToken } from "@/lib/adminAuth";

import { Navbar } from "./components/home/Navbar";
import { Hero } from "./components/home/Hero";
import { Services } from "./components/services";
import { Fleet } from "./components/home/Fleet";
import { Booking } from "./components/booking";
import { Reviews } from "./components/reviews";
import { FAQ } from "./components/faq";
import { Contact } from "./components/contact";
import { Footer } from "./components/footer";

import { FleetPage } from "./pages/FleetPage";
import { VehicleDetailPage } from "./pages/VehicleDetailPage";
import { BlogPage } from "./pages/BlogPage";
import { BlogDetailPage } from "./pages/BlogDetailPage";
import { TourDetailPage } from "./pages/TourDetailPage";
import { ToursPage } from "./pages/ToursPage";
import { ServicesPage } from "./pages/ServicesPage";
import { ServiceDetailPage } from "./pages/ServiceDetailPage";
import { AdminLoginPage } from "./pages/AdminLoginPage";
import { ProtectedRoute } from "./components/ProtectedRoute";
import { AdminDashboardPage } from "./pages/admin/AdminDashboardPage";
import { AdminFleetPage } from "./pages/admin/AdminFleetPage";
import { AdminToursPage } from "./pages/admin/AdminToursPage";
import { AdminServicesPage } from "./pages/admin/AdminServicesPage";
import { AdminBlogPage } from "./pages/admin/AdminBlogPage";
import { AdminBookingsPage } from "./pages/admin/AdminBookingsPage";
import { AdminSiteSettingsPage } from "./pages/admin/AdminSiteSettingsPage";

setAuthTokenGetter(() => getAdminToken());
setUploadAuthTokenGetter(() => getAdminToken());

const queryClient = new QueryClient();

function Home() {
  return (
    <main className="min-h-screen bg-black text-white selection:bg-primary selection:text-black">
      <Navbar />
      <Hero />
      <Services />
      <Fleet />
      <Booking />
      <Reviews />
      <FAQ />
      <Contact />
      <Footer />
    </main>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/fleet" component={FleetPage} />
      <Route path="/fleet/:id" component={VehicleDetailPage} />
      <Route path="/blog" component={BlogPage} />
      <Route path="/blog/:slug" component={BlogDetailPage} />
      <Route path="/tours" component={ToursPage} />
      <Route path="/tours/:slug" component={TourDetailPage} />
      <Route path="/services" component={ServicesPage} />
      <Route path="/services/:slug" component={ServiceDetailPage} />
      <Route path="/admin/login" component={AdminLoginPage} />
      <Route path="/admin">{() => <ProtectedRoute component={AdminDashboardPage} />}</Route>
      <Route path="/admin/fleet">{() => <ProtectedRoute component={AdminFleetPage} />}</Route>
      <Route path="/admin/tours">{() => <ProtectedRoute component={AdminToursPage} />}</Route>
      <Route path="/admin/services">{() => <ProtectedRoute component={AdminServicesPage} />}</Route>
      <Route path="/admin/blog">{() => <ProtectedRoute component={AdminBlogPage} />}</Route>
      <Route path="/admin/bookings">{() => <ProtectedRoute component={AdminBookingsPage} />}</Route>
      <Route path="/admin/site">{() => <ProtectedRoute component={AdminSiteSettingsPage} />}</Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
